#include <stdio.h>
#include <stdlib.h>

void main(void)
{
    int i = 999;
    printf("This is a test %d", i);
}
